# w2v2-to-hidden-states

update package:
python setup.py sdist

reinstall package:

-uninstall package:
pip uninstall git+https://github.com/martijnbentum/w2v2-to-hidden-states-animated-palm-tree.git@86b0cd4aa9763df023bc7303e2f716dda8a4c3d0#egg=w2v2_hidden_states

-install package:
pip install git+https://github.com/martijnbentum/w2v2-to-hidden-states-animated-palm-tree.git
